# Proj1

The code is stored in utils.py and main.py, where utils.py has all the essential functions and main.py has all the experiement.

Please check this [website](https://www.andrew.cmu.edu/course/16-726-sp23/projects/linjiw/proj1/) for a visual presentation.


## utils.py

### SSD

SSD has implemented the SSD matching metric.

### NCC

NCC has implemented the SSD matching metric.


### AutoCrop

AutoCrop is implemented with edge detection and automated crop ratio caclulation.

### Canny

Canny is implemented with cv2.canny and is intergrated into align functions.

### CMEAS

CMEAS is a evolution optimization method and is integrated as a searching algorithm.

## main.py

run main.py to preform all the experiment.

